<x-admin-layout>
    
    <div class="container py-12">
        @livewire('admin.create-category')
    </div>

</x-admin-layout>
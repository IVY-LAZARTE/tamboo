<div>
    <a href="#" class="text-indigo-600 hover:text-indigo-900" wire:click="$set('open',true)">
        Editar
    </a>


</div>

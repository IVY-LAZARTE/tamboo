<x-app-layout>
    
        <div>
    
        @livewire('create-comprobante')
    
         </div>

</x-app-layout>